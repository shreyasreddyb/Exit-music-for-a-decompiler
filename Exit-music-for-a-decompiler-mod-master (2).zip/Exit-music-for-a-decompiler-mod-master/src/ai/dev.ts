
import { config } from 'dotenv';
config();

// import '@/ai/flows/decompile-malware'; // Removed
import '@/ai/flows/analyze-binary-code';
// import '@/ai/flows/synthesize-readable-code'; // Removed
import '@/ai/flows/perform-analysis-flow';
